import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  MainContainer,
  TextContainer,
  Heading,
  Text,
  Button,
  Picture,
  ErrorMessage,
  SuccessMessage,
} from "./StyledEmail";
import EmailPic from "../../../Images/Email.png";
import { useNavigate } from "react-router-dom";

const Email = () => {
  const [emailFromStorage, setEmailFromStorage] = useState("");
  const [phoneNumberFromStorage, setPhoneNumberFromStorage] = useState("");
  const [userFromStorage, setUserFromStorage] = useState("");
  const [error, setError] = useState("");
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const username = localStorage.getItem("user-name");
    const user = localStorage.getItem("user-name");
    const phone_number = localStorage.getItem("phone");

    if (username && phone_number && user) {
      setEmailFromStorage(username);
      setUserFromStorage(user);
      setPhoneNumberFromStorage(phone_number);
    } else {
      setError("Username or phone number not found in storage.");
    }
  }, []);

  const handleVerifyEmail = async () => {
    const url = localStorage.getItem("verification_url");
    const token = localStorage.getItem("auth-token");

    if (
      !url ||
      !token ||
      !emailFromStorage ||
      !phoneNumberFromStorage ||
      !userFromStorage
    ) {
      setError("Token, username, phone number, or verification URL not found.");
      return;
    }

    try {
      const emailVerifyUrl = `https://api.guvenlisatkirala.com/api/email-verify/`;

      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          username: emailFromStorage,
          token,
        },
      };

      const sendOtpResponse = await axios.post(
        "https://api.guvenlisatkirala.com/api/send-otp/",
        { phone_number: phoneNumberFromStorage, User: userFromStorage },
        {
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        }
      );

      if (sendOtpResponse.data && sendOtpResponse.data.success) {
        console.log("OTP sent successfully:", sendOtpResponse.data);
        navigate("/otp");
      } else {
        setError("Failed to send OTP.");
        return;
      }

      const emailResponse = await axios.get(emailVerifyUrl, config);

      if (emailResponse.data && emailResponse.data.success) {
        setMsg("Email verification success.");
        // Proceed with further actions if needed
      } else {
        setError("Email verification failed.");
      }
    } catch (error) {
      console.error("Error verifying email:", error);
      if (
        error.response &&
        error.response.status >= 400 &&
        error.response.status <= 500
      ) {
        setError(error.response.data.error);
      } else {
        setError("Failed to verify email.");
      }
    }
  };

  return (
    <MainContainer>
      <TextContainer>
        <Heading>
          <span>Email </span>
          adresinizi doğrulayın
        </Heading>
        <Text>
          <span>{emailFromStorage} </span>
          adresini kullanıcı olarak girdiniz. Lütfen aşağıdaki butona tıklayarak
          bu e-posta adresini doğrulayın
        </Text>
        {error && <ErrorMessage>{error}</ErrorMessage>}
        {msg && <SuccessMessage>{msg}</SuccessMessage>}
        <Button type="button" onClick={handleVerifyEmail}>
          Hesabınızı Doğrulayın
        </Button>
      </TextContainer>
      <Picture src={EmailPic} alt="EmailPic" />
    </MainContainer>
  );
};

export default Email;
